(function($) {
    $(document).ready(function() {
        var gameIframe = $('.game-iframe iframe');
        var playTime = 0;
        var timer;

        // Start tracking play time when the game iframe loads
        gameIframe.on('load', function() {
            startTimer();
        });

        // Stop tracking play time when the user leaves the page
        $(window).on('beforeunload', function() {
            stopTimer();
            sendStats();
        });

        // Helper functions
        function startTimer() {
            timer = setInterval(function() {
                playTime += 1; // Increment play time every second
            }, 1000);
        }

        function stopTimer() {
            clearInterval(timer);
        }

        function sendStats() {
            var data = {
                action: 'html5_game_embedder_update_stats',
                nonce: html5_game_embedder_data.nonce,
                user_id: html5_game_embedder_data.user_id,
                game_id: html5_game_embedder_data.game_id,
                play_time: playTime
            };

            $.post(html5_game_embedder_data.ajax_url, data, function(response) {
                console.log(response);
            });
        }
    });
})(jQuery);
