<?php
/*
Plugin Name: HTML5 Game Embedder
Plugin URI: https://voidcorp.net
Description: Allows users to embed HTML5 games on their website, track user statistics, and display games in an interactive slider.
Version: 1.2
Author: Void, Corp
Author URI: https://voidcorp.net
*/

// Register custom post type for games
function html5_game_embedder_register_post_type() {
    $labels = array(
        'name'               => __( 'Games', 'html5-game-embedder' ),
        'singular_name'      => __( 'Game', 'html5-game-embedder' ),
        'menu_name'          => __( 'Games', 'html5-game-embedder' ),
        'name_admin_bar'     => __( 'Game', 'html5-game-embedder' ),
        'add_new'            => __( 'Add New', 'html5-game-embedder' ),
        'add_new_item'       => __( 'Add New Game', 'html5-game-embedder' ),
        'new_item'           => __( 'New Game', 'html5-game-embedder' ),
        'edit_item'          => __( 'Edit Game', 'html5-game-embedder' ),
        'view_item'          => __( 'View Game', 'html5-game-embedder' ),
        'all_items'          => __( 'All Games', 'html5-game-embedder' ),
        'search_items'       => __( 'Search Games', 'html5-game-embedder' ),
        'parent_item_colon'  => __( 'Parent Games:', 'html5-game-embedder' ),
        'not_found'          => __( 'No games found.', 'html5-game-embedder' ),
        'not_found_in_trash' => __( 'No games found in Trash.', 'html5-game-embedder' )
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'game' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' )
    );

    register_post_type( 'html5_game', $args );
}
add_action( 'init', 'html5_game_embedder_register_post_type' );

// Register custom taxonomy for game categories
function html5_game_embedder_register_taxonomy() {
    $labels = array(
        'name'              => __( 'Game Categories', 'html5-game-embedder' ),
        'singular_name'     => __( 'Game Category', 'html5-game-embedder' ),
        'search_items'      => __( 'Search Game Categories', 'html5-game-embedder' ),
        'all_items'         => __( 'All Game Categories', 'html5-game-embedder' ),
        'parent_item'       => __( 'Parent Game Category', 'html5-game-embedder' ),
        'parent_item_colon' => __( 'Parent Game Category:', 'html5-game-embedder' ),
        'edit_item'         => __( 'Edit Game Category', 'html5-game-embedder' ),
        'update_item'       => __( 'Update Game Category', 'html5-game-embedder' ),
        'add_new_item'      => __( 'Add New Game Category', 'html5-game-embedder' ),
        'new_item_name'     => __( 'New Game Category Name', 'html5-game-embedder' ),
        'menu_name'         => __( 'Game Categories', 'html5-game-embedder' ),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'game-category' ),
    );

    register_taxonomy( 'game_category', array( 'html5_game' ), $args );
}
add_action( 'init', 'html5_game_embedder_register_taxonomy', 0 );

// Add custom meta boxes for game details
function html5_game_embedder_add_meta_boxes() {
    add_meta_box(
        'html5_game_embedder_iframe_code',
        __( 'Game Iframe Code', 'html5-game-embedder' ),
        'html5_game_embedder_iframe_code_callback',
        'html5_game',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'html5_game_embedder_add_meta_boxes' );

function html5_game_embedder_iframe_code_callback( $post ) {
    wp_nonce_field( 'html5_game_embedder_save_meta_box_data', 'html5_game_embedder_meta_box_nonce' );

    $iframe_code = get_post_meta( $post->ID, '_html5_game_embedder_iframe_code', true );
    ?>
    <label for="html5_game_embedder_iframe_code"><?php _e( 'Iframe Code', 'html5-game-embedder' ); ?></label>
    <textarea id="html5_game_embedder_iframe_code" name="html5_game_embedder_iframe_code" rows="5" style="width: 100%;"><?php echo esc_textarea( $iframe_code ); ?></textarea>
    <?php
}

// Save custom meta box data
function html5_game_embedder_save_meta_box_data( $post_id ) {
    if ( ! isset( $_POST['html5_game_embedder_meta_box_nonce'] ) ) {
        return;
    }

    if ( ! wp_verify_nonce( $_POST['html5_game_embedder_meta_box_nonce'], 'html5_game_embedder_save_meta_box_data' ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    if ( isset( $_POST['html5_game_embedder_iframe_code'] ) ) {
        update_post_meta( $post_id, '_html5_game_embedder_iframe_code', sanitize_textarea_field( $_POST['html5_game_embedder_iframe_code'] ) );
    }
}
add_action( 'save_post', 'html5_game_embedder_save_meta_box_data' );

// Generate shortcode for displaying games
function html5_game_embedder_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'id' => 0,
    ), $atts, 'html5_game_embedder' );

    $post_id = intval( $atts['id'] );

    if ( ! $post_id || get_post_type( $post_id ) !== 'html5_game' ) {
        return '';
    }

    $iframe_code = get_post_meta( $post_id, '_html5_game_embedder_iframe_code', true );
    $game_description = get_the_excerpt( $post_id );
    $game_thumbnail = get_the_post_thumbnail( $post_id, 'thumbnail' );

    $output = '<div class="html5-game-embedder">';
    $output .= '<div class="game-thumbnail">' . $game_thumbnail . '</div>';
    $output .= '<div class="game-description">' . $game_description . '</div>';
    $output .= '<div class="game-iframe">' . $iframe_code . '</div>';
    $output .= '</div>';

    return $output;
}
add_shortcode( 'html5_game_embedder', 'html5_game_embedder_shortcode' );

// Display list of games by category
function html5_game_embedder_category_list( $atts ) {
    $atts = shortcode_atts( array(
        'category' => '',
    ), $atts, 'html5_game_embedder_category_list' );

    $category_slug = sanitize_title( $atts['category'] );
    $category = get_term_by( 'slug', $category_slug, 'game_category' );

    if ( ! $category ) {
        return '';
    }

    $args = array(
        'post_type'      => 'html5_game',
        'posts_per_page' => -1,
        'tax_query'      => array(
            array(
                'taxonomy' => 'game_category',
                'field'    => 'term_id',
                'terms'    => $category->term_id,
            ),
        ),
    );

    $games = new WP_Query( $args );

    if ( ! $games->have_posts() ) {
        return '';
    }

    $output = '<div class="html5-game-embedder-category-list">';
    $output .= '<h2>' . $category->name . '</h2>';
    $output .= '<ul>';

    while ( $games->have_posts() ) {
        $games->the_post();
        $output .= '<li>';
        $output .= '<div class="game-thumbnail">' . get_the_post_thumbnail( get_the_ID(), 'thumbnail' ) . '</div>';
        $output .= '<div class="game-title"><a href="' . get_permalink() . '">' . get_the_title() . '</a></div>';
        $output .= '<div class="game-shortcode">[html5_game_embedder id="' . get_the_ID() . '"]</div>';
        $output .= '</li>';
    }

    $output .= '</ul>';
    $output .= '</div>';

    wp_reset_postdata();

    return $output;
}
add_shortcode( 'html5_game_embedder_category_list', 'html5_game_embedder_category_list' );

// Create a custom database table to store user statistics
function html5_game_embedder_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'html5_game_stats';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        game_id BIGINT(20) UNSIGNED NOT NULL,
        play_time INT(11) UNSIGNED NOT NULL DEFAULT 0,
        plays INT(11) UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY game_id (game_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'html5_game_embedder_create_table');

// Update user statistics when a game is played
function html5_game_embedder_update_stats($user_id, $game_id, $play_time) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'html5_game_stats';

    $existing_stats = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d AND game_id = %d", $user_id, $game_id));

    if ($existing_stats) {
        $new_play_time = $existing_stats->play_time + $play_time;
        $new_plays = $existing_stats->plays + 1;
        $wpdb->update(
            $table_name,
            array(
                'play_time' => $new_play_time,
                'plays' => $new_plays
            ),
            array(
                'user_id' => $user_id,
                'game_id' => $game_id
            )
        );
    } else {
        $wpdb->insert(
            $table_name,
            array(
                'user_id' => $user_id,
                'game_id' => $game_id,
                'play_time' => $play_time,
                'plays' => 1
            )
        );
    }
}

// Shortcode to display the leaderboard
function html5_game_embedder_leaderboard_shortcode($atts) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'html5_game_stats';

    $atts = shortcode_atts(array(
        'limit' => 10,
        'order_by' => 'play_time',
        'order' => 'DESC'
    ), $atts, 'html5_game_embedder_leaderboard');

    $limit = intval($atts['limit']);
    $order_by = sanitize_sql_orderby($atts['order_by']);
    $order = strtoupper($atts['order']) === 'ASC' ? 'ASC' : 'DESC';

    $leaderboard_query = $wpdb->get_results("
        SELECT u.user_login, u.display_name, SUM(s.play_time) AS total_play_time, SUM(s.plays) AS total_plays
        FROM $table_name s
        JOIN {$wpdb->users} u ON s.user_id = u.ID
        GROUP BY s.user_id
        ORDER BY $order_by $order
        LIMIT $limit
    ");

    $output = '<div class="html5-game-embedder-leaderboard">';
    $output .= '<h2>Leaderboard</h2>';
    $output .= '<table>';
    $output .= '<thead><tr><th>User</th><th>Total Play Time</th><th>Total Plays</th></tr></thead>';
    $output .= '<tbody>';

    foreach ($leaderboard_query as $row) {
        $output .= '<tr>';
        $output .= '<td>' . $row->display_name . '</td>';
        $output .= '<td>' . gmdate('H:i:s', $row->total_play_time) . '</td>';
        $output .= '<td>' . $row->total_plays . '</td>';
        $output .= '</tr>';
    }

    $output .= '</tbody>';
    $output .= '</table>';
    $output .= '</div>';

    return $output;
}
add_shortcode('html5_game_embedder_leaderboard', 'html5_game_embedder_leaderboard_shortcode');

function html5_game_embedder_enqueue_styles() {
    wp_enqueue_style('html5-game-embedder-arcade-slider', plugin_dir_url(__FILE__) . 'css/arcade-slider.css', array(), '1.0', 'all');
}
add_action('wp_enqueue_scripts', 'html5_game_embedder_enqueue_styles');

// Shortcode to display the interactive game slider
function html5_game_embedder_slider_shortcode($atts) {
    $atts = shortcode_atts(array(
        'category' => '',
        'limit' => -1,
        'orderby' => 'date',
        'order' => 'DESC'
    ), $atts, 'html5_game_embedder_slider');

    $category_slug = sanitize_title($atts['category']);
    $category = get_term_by('slug', $category_slug, 'game_category');

    $args = array(
        'post_type' => 'html5_game',
        'posts_per_page' => intval($atts['limit']),
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'tax_query' => array(
            array(
                'taxonomy' => 'game_category',
                'field' => 'term_id',
                'terms' => $category ? $category->term_id : '',
            ),
        ),
    );

    $games = new WP_Query($args);

    if (!$games->have_posts()) {
        return '';
    }

    $output = '<div class="html5-game-embedder-slider">';
    $output .= '<div class="slider-container">';

    while ($games->have_posts()) {
        $games->the_post();
        $output .= '<div class="slider-item">';
        $output .= '<a href="' . get_permalink() . '">' . get_the_post_thumbnail(get_the_ID(), 'medium') . '</a>';
        $output .= '<h3>' . get_the_title() . '</h3>';
        $output .= '</div>';
    }

    $output .= '</div>'; // Close .slider-container
    $output .= '</div>'; // Close .html5-game-embedder-slider

    wp_reset_postdata();

    return $output;
}
add_shortcode('html5_game_embedder_slider', 'html5_game_embedder_slider_shortcode');

// Uninstall plugin and remove database table
function html5_game_embedder_uninstall() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'html5_game_stats';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
}
register_uninstall_hook(__FILE__, 'html5_game_embedder_uninstall');


// Enqueue scripts to track user statistics
function html5_game_embedder_enqueue_scripts() {
    wp_enqueue_script('html5-game-embedder-tracker', plugin_dir_url(__FILE__) . 'js/tracker.js', array('jquery'), '1.0', true);
    wp_localize_script('html5-game-embedder-tracker', 'html5_game_embedder_data', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'user_id' => get_current_user_id(),
        'game_id' => get_the_ID()
    ));
}
add_action('wp_enqueue_scripts', 'html5_game_embedder_enqueue_scripts');
